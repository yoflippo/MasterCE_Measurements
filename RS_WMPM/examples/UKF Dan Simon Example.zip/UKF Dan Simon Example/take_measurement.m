function y=take_measurement(x,a,M,R)
y=sqrt(M^2+(x-a)^2)+sqrt(R)*randn;