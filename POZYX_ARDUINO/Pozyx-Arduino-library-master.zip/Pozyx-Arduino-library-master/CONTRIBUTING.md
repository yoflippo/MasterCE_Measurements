# Contributing guide

For now, this'll only be about documentation:

## Generating documentation

To generate the documentation, you'll need to install both Doxygen and Sphinx. 

When these are installed, you can run the following in your favorite shell to build the documentation.

* doxygen Doxyfile
* cd docs
* make html